package com.targettracker.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int REQ_CAMERA = 1;
    private static final int REQ_FILE = 2;
    private static final int REQ_STORAGE = 3;
    private static final int REQ_MIC = 4;

    // ---- microphone for "Sound" hit detection (read natively: more reliable than the WebView's getUserMedia) ----
    private AudioRecord micRec;
    private Thread micThread;
    private volatile boolean micRun;
    private volatile double micThr = 0.3;
    private final Object micLock = new Object();
    private float micPeak = 0f;
    private final ArrayList<Long> micBangs = new ArrayList<Long>();
    private long micQuietUntil = 0;
    private volatile String micErr = "";

    private WebView web;
    private PermissionRequest pendingPerm;
    private ValueCallback<Uri[]> fileCallback;

    private static class Save {
        Uri uri;          // null for the legacy (Android 6-9) file route
        File file;        // used only on the legacy route
        OutputStream os;
        String path;
    }

    private final Map<Integer, Save> saves = new HashMap<>();
    private int nextSaveId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);

        boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        if (debuggable) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(false);
        ws.setSupportZoom(false);
        ws.setBuiltInZoomControls(false);

        // Serves the bundled files from https://appassets.androidplatform.net/ so the page is a
        // "secure context" (required for camera access) and everything works with no network.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        java.util.ArrayList<String> missing = new java.util.ArrayList<String>();
                        boolean any = false;
                        for (String r : request.getResources()) {
                            String perm = null;
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                                perm = Manifest.permission.CAMERA;
                            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                                perm = Manifest.permission.RECORD_AUDIO;
                            }
                            if (perm == null) {
                                continue;
                            }
                            any = true;
                            if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
                                missing.add(perm);
                            }
                        }
                        if (!any) {
                            request.deny();
                            return;
                        }
                        if (missing.isEmpty()) {
                            grantAllowed(request);
                        } else {
                            if (pendingPerm != null) {
                                pendingPerm.deny();
                            }
                            pendingPerm = request;
                            requestPermissions(missing.toArray(new String[0]), REQ_CAMERA);
                        }
                    }
                });
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (request == pendingPerm) {
                    pendingPerm = null;
                }
            }

            // Needed for the "Open file..." buttons (loading saved settings / profiles).
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (Build.VERSION.SDK_INT < 29 && Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
        }

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    /** Grants the camera / microphone parts of a web request for which Android permission is held. */
    private void grantAllowed(PermissionRequest request) {
        java.util.ArrayList<String> ok = new java.util.ArrayList<String>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) {
            request.deny();
        } else {
            request.grant(ok.toArray(new String[0]));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && pendingPerm != null) {
            grantAllowed(pendingPerm);
            pendingPerm = null;
        }
        if (requestCode == REQ_MIC) {
            final boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            web.evaluateJavascript("window.onMicPermission&&window.onMicPermission(" + ok + ")", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            immersive();
        }
    }

    @Override
    protected void onPause() {
        stopMic();      // the page restarts it when needed
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        synchronized (saves) {
            for (Save s : saves.values()) {
                try {
                    s.os.close();
                } catch (Exception ignored) {
                }
            }
            saves.clear();
        }
        web.destroy();
        super.onDestroy();
    }

    /** Android 10+: save through MediaStore (no permission needed). */
    private Save openScoped(String name, String mime) throws Exception {
        Uri collection;
        String dir;
        if (mime.startsWith("video/")) {
            collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_MOVIES;
        } else if (mime.startsWith("image/")) {
            collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_PICTURES;
        } else {
            collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_DOWNLOADS;
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/TargetTracker");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(collection, v);
        if (uri == null) {
            return null;
        }
        OutputStream os = getContentResolver().openOutputStream(uri);
        if (os == null) {
            return null;
        }
        Save s = new Save();
        s.uri = uri;
        s.os = os;
        s.path = dir + "/TargetTracker/" + name;
        return s;
    }

    /** Android 6-9: write straight into Movies / Pictures / Download (needs the storage permission). */
    private Save openLegacy(String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                }
            });
            return null; // the page shows "could not save"; allow storage, then try again
        }
        String dirName;
        if (mime.startsWith("video/")) {
            dirName = Environment.DIRECTORY_MOVIES;
        } else if (mime.startsWith("image/")) {
            dirName = Environment.DIRECTORY_PICTURES;
        } else {
            dirName = Environment.DIRECTORY_DOWNLOADS;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(dirName), "TargetTracker");
        if (!dir.exists() && !dir.mkdirs()) {
            return null;
        }
        File f = new File(dir, name);
        Save s = new Save();
        s.file = f;
        s.os = new FileOutputStream(f);
        s.path = dirName + "/TargetTracker/" + name;
        return s;
    }

    /** Opens the microphone and starts a thread that tracks the loudest sample and detects bangs. */
    private boolean startMic() {
        int[] rates = {44100, 16000, 48000, 22050, 8000};
        int[] sources = {MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC};
        StringBuilder err = new StringBuilder();
        for (int src : sources) {
            for (int rate : rates) {
                AudioRecord r = null;
                try {
                    int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                    if (min <= 0) {
                        continue;
                    }
                    r = new AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 2048) * 2);
                    if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                        err.append("src").append(src).append("/").append(rate).append(": not initialised; ");
                        r.release();
                        continue;
                    }
                    r.startRecording();
                    if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                        err.append("src").append(src).append("/").append(rate).append(": would not start; ");
                        r.release();
                        continue;
                    }
                    micRec = r;
                    micRun = true;
                    final AudioRecord rec = r;
                    micThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            short[] buf = new short[512];
                            while (micRun) {
                                int n = rec.read(buf, 0, buf.length);
                                if (n <= 0) {
                                    if (n < 0) {
                                        break;
                                    }
                                    continue;
                                }
                                int pk = 0;
                                for (int i = 0; i < n; i++) {
                                    int v = buf[i] < 0 ? -buf[i] : buf[i];
                                    if (v > pk) {
                                        pk = v;
                                    }
                                }
                                float level = pk / 32768f;
                                long now = SystemClock.elapsedRealtime();
                                synchronized (micLock) {
                                    if (level > micPeak) {
                                        micPeak = level;
                                    }
                                    if (level > micThr) {
                                        if (now > micQuietUntil) {
                                            micBangs.add(now);
                                        }
                                        micQuietUntil = now + 350;
                                    }
                                }
                            }
                        }
                    });
                    micThread.start();
                    micErr = "";
                    return true;
                } catch (Exception e) {
                    err.append(e.toString()).append("; ");
                    if (r != null) {
                        try {
                            r.release();
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        }
        micErr = err.length() > 0 ? err.toString() : "no usable audio input";
        return false;
    }

    private void stopMic() {
        micRun = false;
        try {
            if (micThread != null) {
                micThread.join(500);
            }
        } catch (InterruptedException ignored) {
        }
        micThread = null;
        if (micRec != null) {
            try {
                micRec.stop();
            } catch (Exception ignored) {
            }
            micRec.release();
            micRec = null;
        }
        synchronized (micLock) {
            micBangs.clear();
            micPeak = 0f;
        }
    }

    /** Methods the page calls as window.AndroidBridge.xxx(). Files go to Movies / Pictures / Download. */
    public class Bridge {

        /** 1 = microphone running, 0 = permission was just requested, -1 = failed (see micError). */
        @JavascriptInterface
        public int micStart(double thr) {
            micThr = thr;
            if (micRun) {
                return 1;
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                });
                return 0;
            }
            return startMic() ? 1 : -1;
        }

        @JavascriptInterface
        public void micSetThreshold(double thr) {
            micThr = thr;
        }

        @JavascriptInterface
        public void micStop() {
            stopMic();
        }

        @JavascriptInterface
        public String micError() {
            return micErr;
        }

        /** "peak,age1,age2..." : loudest level since the last call (0..1) and how many ms ago each bang happened. */
        @JavascriptInterface
        public String micPoll() {
            long now = SystemClock.elapsedRealtime();
            StringBuilder sb = new StringBuilder();
            synchronized (micLock) {
                sb.append(micPeak);
                micPeak = 0f;
                for (Long t : micBangs) {
                    sb.append(',').append(now - t);
                }
                micBangs.clear();
            }
            return sb.toString();
        }


        @JavascriptInterface
        public int beginSave(String name, String mime) {
            try {
                Save s = (Build.VERSION.SDK_INT >= 29) ? openScoped(name, mime) : openLegacy(name, mime);
                if (s == null) {
                    return -1;
                }
                synchronized (saves) {
                    int id = nextSaveId++;
                    saves.put(id, s);
                    return id;
                }
            } catch (Exception e) {
                return -1;
            }
        }

        @JavascriptInterface
        public boolean writeChunk(int id, String base64) {
            Save s;
            synchronized (saves) {
                s = saves.get(id);
            }
            if (s == null) {
                return false;
            }
            try {
                s.os.write(Base64.decode(base64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String endSave(int id) {
            Save s;
            synchronized (saves) {
                s = saves.remove(id);
            }
            if (s == null) {
                return "";
            }
            try {
                s.os.close();
                if (s.uri != null) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(s.uri, v, null, null);
                } else if (s.file != null) {
                    // make the new file show up in Gallery / file managers
                    MediaScannerConnection.scanFile(MainActivity.this, new String[]{s.file.getAbsolutePath()}, null, null);
                }
            } catch (Exception ignored) {
            }
            return s.path;
        }

        @JavascriptInterface
        public void abortSave(int id) {
            Save s;
            synchronized (saves) {
                s = saves.remove(id);
            }
            if (s == null) {
                return;
            }
            try {
                s.os.close();
            } catch (Exception ignored) {
            }
            try {
                if (s.uri != null) {
                    getContentResolver().delete(s.uri, null, null);
                } else if (s.file != null) {
                    s.file.delete();
                }
            } catch (Exception ignored) {
            }
        }
    }
}
